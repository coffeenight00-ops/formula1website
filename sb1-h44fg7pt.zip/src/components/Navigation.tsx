import { Menu, X, Zap } from 'lucide-react';
import { useState } from 'react';
import { themeConfig, Theme } from '../utils/themeColors';

interface NavigationProps {
  theme: Theme;
}

export default function Navigation({ theme }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const colors = themeConfig[theme];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  return (
    <nav className={`fixed top-0 w-full z-50 bg-black/95 backdrop-blur-sm border-b ${colors.border} transition-all`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 bg-gradient-to-br ${colors.logo} rounded-full flex items-center justify-center font-bold text-white shadow-lg`}>
              <Zap size={20} />
            </div>
            <span className="text-white font-bold text-lg tracking-wider hidden sm:inline">STEM RACING</span>
          </div>

          <div className="hidden md:flex items-center space-x-1">
            <button onClick={() => scrollToSection('home')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Home
            </button>
            <button onClick={() => scrollToSection('car')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Car
            </button>
            <button onClick={() => scrollToSection('stats')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Stats
            </button>
            <button onClick={() => scrollToSection('achievements')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Awards
            </button>
            <button onClick={() => scrollToSection('gallery')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Gallery
            </button>
            <button onClick={() => scrollToSection('blog')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              News
            </button>
            <button onClick={() => scrollToSection('contact')} className={`px-3 py-2 rounded-lg text-gray-300 ${colors.hover} transition-colors font-medium text-sm`}>
              Contact
            </button>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className={`md:hidden bg-black/98 border-t ${colors.border}`}>
          <div className="px-4 py-4 space-y-2">
            {['home', 'car', 'stats', 'achievements', 'gallery', 'blog', 'contact'].map((id) => (
              <button
                key={id}
                onClick={() => scrollToSection(id)}
                className={`block w-full text-left px-3 py-2 text-gray-300 ${colors.hover} transition-colors rounded-lg`}
              >
                {id.charAt(0).toUpperCase() + id.slice(1)}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
