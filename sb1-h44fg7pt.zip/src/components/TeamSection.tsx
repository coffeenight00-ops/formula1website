import { Trophy, Target, Lightbulb, Users } from 'lucide-react';

export default function TeamSection() {
  const values = [
    {
      icon: Trophy,
      title: 'Excellence',
      description: 'Striving for perfection in every aspect of our design and engineering',
    },
    {
      icon: Target,
      title: 'Precision',
      description: 'Attention to detail in every component and calculation',
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Pushing boundaries with creative solutions and new technologies',
    },
    {
      icon: Users,
      title: 'Teamwork',
      description: 'Collaboration and communication driving our success',
    },
  ];

  return (
    <section id="team" className="relative py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-12 h-1 bg-yellow-400"></div>
              <span className="text-yellow-400 font-semibold tracking-widest uppercase">About Us</span>
              <div className="w-12 h-1 bg-yellow-400"></div>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">STEM Racing Team</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            A passionate group of students dedicated to excellence in engineering, design, and innovation.
          </p>
        </div>

        <div className="mb-16">
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 md:p-12 border border-yellow-400/30 shadow-2xl">
            <h3 className="text-2xl font-bold text-white mb-6">Our Mission</h3>
            <p className="text-gray-300 leading-relaxed mb-6">
              STEM Racing was founded with a singular vision: to bridge the gap between theoretical knowledge and practical application.
              Our team combines expertise in mechanical engineering, aerodynamics, electronics, and design to create a competitive
              Formula 1 model car that showcases the power of STEM education.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Through countless hours of design iterations, simulations, and testing, we've developed not just a model car,
              but a comprehensive understanding of automotive engineering principles. Every component of our car tells a story
              of problem-solving, innovation, and teamwork.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {values.map((value, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-gray-800/80 to-gray-900/80 rounded-xl p-6 border border-yellow-400/20 hover:border-yellow-400 transition-all hover:scale-105"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-4 group-hover:shadow-lg group-hover:shadow-yellow-400/50 transition-all">
                <value.icon size={28} className="text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{value.title}</h3>
              <p className="text-gray-400 text-sm">{value.description}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-yellow-400/20 to-yellow-600/20 rounded-xl p-6 border border-yellow-400/40">
            <div className="text-4xl font-bold text-white mb-2">500+</div>
            <p className="text-gray-300">Hours of Design</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-400/20 to-yellow-600/20 rounded-xl p-6 border border-yellow-400/40">
            <div className="text-4xl font-bold text-white mb-2">50+</div>
            <p className="text-gray-300">Design Iterations</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-400/20 to-yellow-600/20 rounded-xl p-6 border border-yellow-400/40">
            <div className="text-4xl font-bold text-white mb-2">100%</div>
            <p className="text-gray-300">Team Dedication</p>
          </div>
        </div>
      </div>
    </section>
  );
}
