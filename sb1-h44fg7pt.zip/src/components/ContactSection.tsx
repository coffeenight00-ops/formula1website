import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { themeConfig, Theme } from '../utils/themeColors';

interface ContactSectionProps {
  theme: Theme;
}

export default function ContactSection({ theme }: ContactSectionProps) {
  const colors = themeConfig[theme];

  return (
    <section id="contact" className="relative py-20 bg-black">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-1/4 w-96 h-96 opacity-10 rounded-full blur-3xl" style={{ backgroundColor: colors.text }}></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center space-x-2">
              <div className={`w-12 h-1 ${colors.accent}`}></div>
              <span className={`${colors.text} font-semibold tracking-widest uppercase`}>Get In Touch</span>
              <div className={`w-12 h-1 ${colors.accent}`}></div>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Contact & Sponsorship</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Interested in sponsoring STEM Racing or have questions? We'd love to hear from you!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className={`bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-xl p-6 border ${colors.accentLight}`}>
            <div className={`w-12 h-12 ${colors.accent} rounded-full flex items-center justify-center mb-4`}>
              <Mail size={24} className="text-white" />
            </div>
            <h3 className="text-white font-semibold mb-2">Email</h3>
            <p className="text-gray-400">contact@stemracing.com</p>
            <p className="text-gray-400">sponsorship@stemracing.com</p>
          </div>

          <div className={`bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-xl p-6 border ${colors.accentLight}`}>
            <div className={`w-12 h-12 ${colors.accent} rounded-full flex items-center justify-center mb-4`}>
              <Phone size={24} className="text-white" />
            </div>
            <h3 className="text-white font-semibold mb-2">Phone</h3>
            <p className="text-gray-400">+1 (555) 123-4567</p>
            <p className="text-gray-400">Available Mon-Fri 9AM-5PM</p>
          </div>

          <div className={`bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-xl p-6 border ${colors.accentLight}`}>
            <div className={`w-12 h-12 ${colors.accent} rounded-full flex items-center justify-center mb-4`}>
              <MapPin size={24} className="text-white" />
            </div>
            <h3 className="text-white font-semibold mb-2">Location</h3>
            <p className="text-gray-400">City, State</p>
            <p className="text-gray-400">Country</p>
          </div>
        </div>

        <div className={`bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 md:p-12 border ${colors.accentLight}`}>
          <h3 className="text-2xl font-bold text-white mb-8">Send Us a Message</h3>
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-gray-300 font-semibold mb-2">Name</label>
                <input type="text" className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-current transition-colors" style={{ focusBorderColor: colors.text }} placeholder="Your name" />
              </div>
              <div>
                <label className="block text-gray-300 font-semibold mb-2">Email</label>
                <input type="email" className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-current transition-colors" style={{ focusBorderColor: colors.text }} placeholder="your@email.com" />
              </div>
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Subject</label>
              <input type="text" className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-current transition-colors" style={{ focusBorderColor: colors.text }} placeholder="How can we help?" />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Message</label>
              <textarea rows={5} className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-current transition-colors" style={{ focusBorderColor: colors.text }} placeholder="Your message here..."></textarea>
            </div>
            <button className={`w-full bg-gradient-to-r ${colors.bg} text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2`} style={{ boxShadow: `0 0 20px ${colors.glowShadow.split('/')[0]}50` }}>
              <Send size={20} />
              <span>Send Message</span>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
