import { Mail, Linkedin, Twitter, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-yellow-400/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center font-bold text-white">
                SR
              </div>
              <span className="text-white font-bold text-xl tracking-wider">STEM RACING</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Engineering excellence in motion. Building the future of STEM education through competitive racing.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-yellow-500 transition-colors text-sm">Home</a></li>
              <li><a href="#car" className="text-gray-400 hover:text-yellow-500 transition-colors text-sm">Our Car</a></li>
              <li><a href="#team" className="text-gray-400 hover:text-yellow-500 transition-colors text-sm">About Team</a></li>
              <li><a href="#members" className="text-gray-400 hover:text-yellow-500 transition-colors text-sm">Team Members</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Connect With Us</h3>
            <div className="flex space-x-3 mb-4">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-400 transition-colors">
                <Mail size={18} className="text-white" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-400 transition-colors">
                <Linkedin size={18} className="text-white" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-400 transition-colors">
                <Twitter size={18} className="text-white" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-400 transition-colors">
                <Instagram size={18} className="text-white" />
              </a>
            </div>
            <p className="text-gray-400 text-sm">contact@stemracing.com</p>
          </div>
        </div>

        <div className="border-t border-yellow-400/30 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              © 2024 STEM Racing. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-500 hover:text-yellow-500 text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-500 hover:text-yellow-500 text-sm transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
