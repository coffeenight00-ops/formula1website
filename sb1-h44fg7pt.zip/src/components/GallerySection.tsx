import { Image, Play } from 'lucide-react';
import { themeConfig, Theme } from '../utils/themeColors';

interface GallerySectionProps {
  theme: Theme;
}

export default function GallerySection({ theme }: GallerySectionProps) {
  const colors = themeConfig[theme];

  const items = Array.from({ length: 8 }, (_, i) => ({
    id: i + 1,
    type: i % 3 === 0 ? 'video' : 'image',
  }));

  return (
    <section id="gallery" className="relative py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center space-x-2">
              <div className={`w-12 h-1 ${colors.accent}`}></div>
              <span className={`${colors.text} font-semibold tracking-widest uppercase`}>Gallery</span>
              <div className={`w-12 h-1 ${colors.accent}`}></div>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Project Gallery</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {items.map((item) => (
            <div key={item.id} className={`h-48 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg border ${colors.accentLight} flex items-center justify-center group hover:scale-105 transition-transform cursor-pointer relative`}>
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                {item.type === 'video' ? (
                  <Play size={48} className={colors.text} />
                ) : (
                  <Image size={48} className={colors.text} />
                )}
              </div>
              {item.type === 'video' && (
                <div className={`absolute top-2 right-2 w-8 h-8 rounded-full ${colors.accent} flex items-center justify-center opacity-70`}>
                  <Play size={16} className="text-white fill-white" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
