import { Gauge, Wind, Zap, Settings } from 'lucide-react';

export default function CarSection() {
  const specs = [
    { icon: Gauge, label: 'Top Speed', value: 'TBD km/h' },
    { icon: Wind, label: 'Aerodynamics', value: 'Optimized' },
    { icon: Zap, label: 'Power Unit', value: 'Electric' },
    { icon: Settings, label: 'Weight', value: 'TBD kg' },
  ];

  return (
    <section id="car" className="relative py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-12 h-1 bg-yellow-400"></div>
              <span className="text-yellow-400 font-semibold tracking-widest uppercase">Our Machine</span>
              <div className="w-12 h-1 bg-yellow-400"></div>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">The Formula SR-1</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            A masterpiece of engineering, designed and built by our talented team using Fusion 360 and cutting-edge manufacturing techniques.
          </p>
        </div>

        <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 md:p-12 border border-yellow-400/30 shadow-2xl mb-12">
          <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl flex items-center justify-center border-2 border-dashed border-yellow-400/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            <div className="relative text-center">
              <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg shadow-yellow-400/50">
                <Settings size={48} className="text-white animate-spin-slow" />
              </div>
              <p className="text-gray-400 text-lg mb-2">3D Model Viewer</p>
              <p className="text-gray-500 text-sm">Import your Fusion 360 model here</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {specs.map((spec, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-gray-800/80 to-gray-900/80 rounded-xl p-6 border border-yellow-400/20 hover:border-yellow-400 transition-all hover:scale-105"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-lg flex items-center justify-center mb-4 group-hover:shadow-lg group-hover:shadow-yellow-400/50 transition-all">
                <spec.icon size={24} className="text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">{spec.label}</h3>
              <p className="text-gray-400">{spec.value}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 border border-yellow-400/30">
          <h3 className="text-2xl font-bold text-white mb-6">Technical Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
              <div>
                <h4 className="text-white font-semibold mb-1">Advanced Aerodynamics</h4>
                <p className="text-gray-400 text-sm">Front and rear wings optimized for maximum downforce and minimal drag</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
              <div>
                <h4 className="text-white font-semibold mb-1">Lightweight Chassis</h4>
                <p className="text-gray-400 text-sm">Carbon fiber composite construction for optimal strength-to-weight ratio</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
              <div>
                <h4 className="text-white font-semibold mb-1">Precision Steering</h4>
                <p className="text-gray-400 text-sm">High-precision steering system for accurate control and handling</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
              <div>
                <h4 className="text-white font-semibold mb-1">Optimized Suspension</h4>
                <p className="text-gray-400 text-sm">Adjustable suspension geometry for different track conditions</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
