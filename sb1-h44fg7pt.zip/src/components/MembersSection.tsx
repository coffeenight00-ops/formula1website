import { User, Mail, Linkedin } from 'lucide-react';

export default function MembersSection() {
  const members = [
    {
      name: 'Team Member 1',
      role: 'Team Leader & Chief Engineer',
      description: 'Oversees project development and coordinates all team activities',
    },
    {
      name: 'Team Member 2',
      role: 'Aerodynamics Specialist',
      description: 'Designs and optimizes wing profiles and body aerodynamics',
    },
    {
      name: 'Team Member 3',
      role: 'Mechanical Engineer',
      description: 'Responsible for chassis design and structural integrity',
    },
    {
      name: 'Team Member 4',
      role: 'Electronics & Controls',
      description: 'Develops electrical systems and control mechanisms',
    },
    {
      name: 'Team Member 5',
      role: 'CAD Designer',
      description: 'Creates detailed 3D models and technical drawings',
    },
    {
      name: 'Team Member 6',
      role: 'Testing & Analysis',
      description: 'Conducts performance testing and data analysis',
    },
  ];

  return (
    <section id="members" className="relative py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-12 h-1 bg-yellow-400"></div>
              <span className="text-yellow-400 font-semibold tracking-widest uppercase">The Team</span>
              <div className="w-12 h-1 bg-yellow-400"></div>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Meet Our Engineers</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            The brilliant minds behind STEM Racing, each bringing unique skills and expertise to create excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {members.map((member, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-gray-800/80 to-gray-900/80 rounded-xl overflow-hidden border border-yellow-400/20 hover:border-yellow-400 transition-all hover:scale-105"
            >
              <div className="h-48 bg-gradient-to-br from-yellow-400/30 to-yellow-600/30 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900 opacity-50"></div>
                <div className="relative w-24 h-24 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg shadow-yellow-400/50 group-hover:scale-110 transition-transform">
                  <User size={48} className="text-white" />
                </div>
                <div className="absolute top-3 right-3 flex space-x-2">
                  <button className="w-8 h-8 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                    <Mail size={16} className="text-white" />
                  </button>
                  <button className="w-8 h-8 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                    <Linkedin size={16} className="text-white" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="w-8 h-0.5 bg-yellow-400"></div>
                  <p className="text-yellow-500 text-sm font-semibold">{member.role}</p>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">{member.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 md:p-12 border border-yellow-400/30 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Join Our Team</h3>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Interested in becoming part of STEM Racing? We're always looking for passionate individuals who want to push the boundaries of engineering and design.
          </p>
          <button className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-8 py-3 rounded-full font-semibold hover:from-yellow-500 hover:to-yellow-600 transition-all shadow-lg shadow-yellow-400/50 hover:shadow-yellow-400/70">
            Get in Touch
          </button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>
    </section>
  );
}
